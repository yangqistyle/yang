package com.coding.studiodemo.exception;

import com.coding.studiodemo.annotation.PassToken;
import com.coding.studiodemo.annotation.Role;
import com.coding.studiodemo.annotation.UserLoginToken;
import com.coding.studiodemo.common.R;
import com.coding.studiodemo.domain.entity.User;
import com.coding.studiodemo.service.UserService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.Date;

public class AuthenticationInterceptor implements HandlerInterceptor {
    @Autowired
    UserService userService;

    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse
                             httpServletResponse,Object object) throws Exception{
        String token=httpServletRequest.getHeader("token");

        if(!(object instanceof HandlerMethod)){
            return true;
        }
        HandlerMethod handlerMethod=(HandlerMethod)object;
        Method method=handlerMethod.getMethod();
        if(method.isAnnotationPresent(PassToken.class)){
            PassToken passToken=method.getAnnotation(PassToken.class);
            if (passToken.required()){
                return true;
            }
        }
        if (method.isAnnotationPresent(UserLoginToken.class)){
            if (token==null){
                throw new InvalidClientException("无Token,请重新登录");
            }
            Jws<Claims> jwt = Jwts.parser()
                    .setSigningKey(R.KEY)
                    .parseClaimsJws(token);
            long userId = jwt.getBody().get("id",Long.class);

            User user=userService.getUser(userId);
            if(user==null){
                throw new Exception("用户不存在，请重新登录");
            }
            if (jwt.getBody().get("exp",Date.class).before(new Date())){
                throw new Exception("登录超时，请从新登陆");
            }
            if(method.isAnnotationPresent(Role.class)){
                Role role=method.getAnnotation(Role.class);
                if (!(user.getRole().equals(role.value()))){
                    throw new Exception("普通用户不能进行该操作！");
                }
                return true;
            }
            return true;
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest,
                           HttpServletResponse httpServletResponse,
                           Object o, ModelAndView modelAndView)throws Exception{

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest,
                                HttpServletResponse httpServletResponse,
                                Object o,Exception e)throws Exception{

    }

}
