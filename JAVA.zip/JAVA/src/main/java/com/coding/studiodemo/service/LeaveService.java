package com.coding.studiodemo.service;

import com.coding.studiodemo.domain.entity.Leaves;

import java.util.List;

public interface LeaveService {

    void create(Leaves leaves);                        //普通用户发起请假和admin审批

    Leaves getUserStartLeave(Long id,String state);    //获取用户正在发起的请假单

    List<Leaves> getUserLeave(Long id);                //查看当前用户所有请假单列表

    List<Leaves> getAllUserStartLeave(String state);   //查看所有用户的发起请假列表

    List<Leaves> getAllUserLeave();                    //查看所有用户的所有请假列表
}
